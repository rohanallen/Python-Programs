import math
print(math.sin(math.pi/2))
print(dir(math))# print content of modules

#pi and math.pi are diff variables
pi = 3.14

def sin(x):
    if 2 * x == pi:
        return 0.99999999
    else:
        return None

print(sin(pi/2))

#or
#from module import * to import everything
#import module as alias
#from math import pi as PI, sin as sine
#import math as m

from math import sin, pi

print(sin(pi/2))

pi = 3.14

def sin(x):
    if 2 * x == pi:
        return 0.99999999
    else:
        return None

print(sin(pi/2))
# line 01: carry out the selective import;
# line 03: make use of the imported entities and get the expected result (1.0)
# lines 05 through 11: redefine the meaning of pi and sin - in effect, they supersede the original (imported) definitions within the code's namespace;
# line 13: get 0.99999999, which confirms our conclusions.

#############################################
#random module
import random
print(dir(random))

from platform import platform

print(platform())
print(platform(1))
print(platform(0, 1))