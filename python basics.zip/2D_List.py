EMPTY = "-"
ROOK = "ROOK"
board = []

for i in range(8):
    row = [EMPTY for i in range(8)]
    board.append(row)

board[0][0] = ROOK
board[0][7] = ROOK
board[7][0] = ROOK
board[7][7] = ROOK

print(board)

###or
r=int(input("enter no of rows"))
c=int(input("enter no of columns"))
matrix=[]
for i in range(0,r):
	matrix.append([])
	for j in range(0,c):
		matrix[i].append(int(input()))
print("ORIGINAL MATRIX")
for i in range(0,r):
	for j in range(0,c):
		print(matrix[i][j],end=' ')
	print("\n")