i = 15
j = 22
i = 0b00000000000000000000000000001111
j = 0b00000000000000000000000000010110
log = i and j
print(log)# larger no

bit = i & j#performs bit wise and operation to get int value of 6
print(bit)

logneg = not i
print(logneg) #The logneg variable will be set to False - nothing more needs to be done.

bitneg = ~i
print(bitneg)#inverts all the individual bits of i(15) to get int value of -16

logor = i or j#smaller no
print(logor)

bitor = i | j
print(bitor)

xor=i^j
print(xor)#xor of individual bits