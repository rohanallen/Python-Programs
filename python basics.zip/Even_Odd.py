a=int(input("Enter Number: "))
if(a%2==0):
  print(a,"is an Even Number.")
else:
    print(a,"is an Odd Number.")