s=input("Enter Sentence: ")# to count no of upper and lower case digit
l=len(s)# length of dtring
count1=0
count2=0
# same as for i in range(0,l,1):
for i in range(l):# by default starts from 0 to l-1 and increments i by 1
  if(s[i].isupper()):
    count1=count1+1
  elif(s[i].islower()):
    count2=count2+1
  else:
	  continue
print("No of upper case digits =" ,(count1))
print("No of lower case digits =" ,(count2))