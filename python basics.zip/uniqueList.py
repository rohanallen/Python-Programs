myList = [1, 2, 4, 4, 1, 4, 2, 6, 2, 9]
myList.sort()
l=len(myList)
uniqueList=[]
for i in range(l-1):
    if myList[i]==myList[i+1]:
        continue
    else:
        uniqueList.append(myList[i])
uniqueList.append(myList[l-1])
uniqueList.sort()
print("The list with unique elements only:")
print(uniqueList)