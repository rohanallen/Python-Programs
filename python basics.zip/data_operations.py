print(2+2)#4
print(-4. + 8)#4.0
print(2*10)#20
print(2*10+2)#22
print(10%3)# modulus is 1
print(12 % 4.5)#3.0

# if any one operand is float result is float
# exponent
print (2**3)#8
print (2.**3)#8.0

#div with fractional part
# div by default has frac part
print(6 / 3)# 2.0
#div with no frac part
print(6//3)#2
print(6 // 3.)#2.0 as it is float
print(10//4.)#2.0 not 2.5, frac part is always 0
print(-6 // 4)#-2 as -1.5 is rounded to smallest integer
# by default expressions are calculated frm lefthandside
#unary + and - have the highest priority
#then: **, then: *, /, and %, and then the lowest priority: binary + and -.

# The exponentiation operator uses right-sided binding, e.g., 2 ** 2 ** 3 = 256.


