#Prime Number or not
def prime(n):
    isPrime=True
    if (n<=1):
        isPrime=False
    for i in range(2,n//2+1):#integer div is req
        if n%i==0:
            isPrime=False
            break
        else:
            continue
    if isPrime:
        print(n,"is a Prime Number")
    else:
        print(n,"is not a Prime Number")
n=int(input("Enter Number: "))
prime(n) # function call