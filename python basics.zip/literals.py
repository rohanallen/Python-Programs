#def of a literal
#Literals are notations for representing some fixed values in code. Python has various types of literals - for example, a literal can be a number (numeric literals, e.g., 123), or a string (string literals, e.g., "I am a literal.").

# same thing
# decimal no
print(11111111);
print(11_111_111);
# no char except underscore and digits is allowed in numeric literals

#octal no
#in decimal 83
print(0o123);

#hexa-decimal no
#in decimal 291
print(0x123);

a=0o123+0x123;
print(a) #83+291=374

print(oct(10))# to print in octal
#float no
a=2.5;
print(a)

#scientific notation
b=3e8 #3x10^8 it is also a float no
c=6.62607e-34# planks constant
# as planks constant is so small, it is not economical to put 34 0s before decimal point, that is why output is also in same format as input
print(b,c)

# strings
# backslash gives a special meaning to next char which follows it
#The first is based on the concept we already know of the escape character, which you should remember is played by the backslash. The backslash can escape quotes too. A quote preceded by a backslash changes its meaning - it's not a delimiter, but just a quote. This will work as intended:
print("I like \"Monty Python\"")
# or
print ('I like "Monty Python"')

#boolean literal
print (2>3)#False
print (True>False) # True as 1>0
print (False>True) # False as 1>0
print (2==2)#True
print (2==2.)#True
print (2!=2)#False

#Write a one-line piece of code, using the print() function, as well as the newline and escape characters, to match the expected result outputted on three lines.
#Expected output
#"I'm"
#""learning""
#"""Python"""

print ('"I\'m"\n""learning""\n"""Python"""')
