# -*- coding: utf-8 -*-
"""
Created on Sun Jun 21 16:25:17 2020

@author: Rohan
"""
print ("Hello World")
print ()#prints nothing just blank space
print ("Hello Rohan")

# newline -> \n
print()
print("The itsy bitsy spider\nclimbed up the waterspout.")
print()
print("Down came the rain\nand washed the spider out.")
print()
#printing multiple arguments
print("Rohan","Allen")
print()
#end keyword used to end the line with whatever arg and then print next line acc
print("My name is", "Python.", end=" ")
print("Monty Python.")
print()
#end keyword next line
print("My name is", "Python.", end="\n")
print("Monty Python.")
print()
#end keyword next line after printing abc
print("My name is", "Python.", end="abc \n")
print("Monty Python.")
print()
#seperates by -
#we can sep ny \n also and anything else we want to
print("My", "name", "is", "Monty", "Python.", sep="-")
print()
# combining both, end always has to be last argument
print("My", "name", "is", sep="_", end="*")
print("Monty", "Python.", sep="*", end="*\n")