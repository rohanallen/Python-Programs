# whole objective of having child class is to
# add additional functionality later on
class Stack:
    def __init__(self):
        self.__stackList = []

    def push(self, val):
        self.__stackList.append(val)

    def pop(self):
        val = self.__stackList[-1]
        del self.__stackList[-1]
        return val

# sub-class of stack
class AddingStack(Stack):
    # def constructor of child class
    def __init__(self):
        #explicit call to parent def constructor (mandatory)
        Stack.__init__(self)
        self.__sum = 0# initialize private variable to 0

# to return sum of stack
    def getSum(self):
        return self.__sum

    def push(self, val):
        self.__sum += val# to calc sum
        # method overriding
        Stack.push(self, val)# calls parent push method

    def pop(self):
        val = Stack.pop(self)# call parent method
        self.__sum -= val# to subtract popped val frm sum
        return val

# creating object of child class. automatically gets all features of parent Stack class
stackObject = AddingStack()

for i in range(5):
    stackObject.push(i)
print(stackObject.getSum())

for i in range(5):
    print(stackObject.pop())
   