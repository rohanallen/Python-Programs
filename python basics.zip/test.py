from platform import processor

print(processor())