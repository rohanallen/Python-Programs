list1=[1,2,3,4,5]
print("List Contents:",list1)
print("List Length:",len(list1))#length of a list

#change first element to 111
list1[0]=111
print("List Contents:",list1)
print("List Length:",len(list1))

 # copying value of the fifth element to the second
list1[1] = list1[4]
print("List Contents:",list1)
print("List Length:",len(list1))

# lists can contain any data type
list1[0]="Rohan"
print(list1[0])

#to remove 3rd element
del list1[2]
print("List Contents:",list1)
print("List Length:",len(list1))

# to acces last element use index of -1, second last -2 and so on
print("Last Element:",list1[-1])
print("Second Last Element:",list1[-2])

#to add element at last place
list1.append(23)
print("List Contents:",list1)
print("List Length:",len(list1))

#to add element at a particular location(index)
list1.insert(1,43)
print("List Contents:",list1)
print("List Length:",len(list1))

#prints 1-5 in reverse order
myList1 = [] # creating an empty list

for i in range(5):
    myList1.insert(0, i + 1)

print(myList1)

#to swap
myList = [10, 1, 8, 3, 5]
length = len(myList)
#works for any list size
for i in range(length // 2):
    myList[i], myList[length - i - 1] = myList[length - i - 1], myList[i]

print(myList)

# Copying part of the list
myList = [10, 8, 6, 4, 2]
newList = myList[1:3]# copies from index 1 to 3-1
print(newList)#[8,6]
# we can also delete part of lists lyk dis using slices

# checks in list or not
myList2 = [0, 3, 12, 8, 2]

print(5 in myList2)#False
print(5 not in myList2)#True
print(12 in myList2)#True

#The snippet produces a ten-element list filled with squares of ten integer numbers starting from zero (0, 1, 4, 9, 16, 25, 36, 49, 64, 81)
# The snippet makes a list with only the odd elements of the squares list.
squares = [x ** 2 for x in range(10)]
odds = [x for x in squares if x % 2 != 0 ]
print(squares)
print(odds)


# print sum of elements in a list
n=int(input("Enter Number of Elements: "))
list=[]
total=0
for i in range(n):
    print("Enter Element",i+1)
    a=int(input())
    total=total+a
    list.append(a)
    #to sort
list.sort()
print("List Elements:",list)
print("Sum of List Elements:",total)
# or
#print(sum(list))

#some methods
#list.reverse()
#list.sort()
#sum(list)
#del list to delete entire list
#myList[:end] by default start is index 0
#myList[start:] bt default end is len of list
#myList[:] omitting start and end makes copy of whole list





