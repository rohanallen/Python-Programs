# + is used to concatenate string
fname="Rohan"
print(fname+"Allen")
print(fname*3)# repeats x amt of times
print(5*fname)# repeats x amt of times
print(0*fname)# value of 0 or less means null value is returned
# a rectangle
print("+" + 10 * "-" + "+")
print(("|" + " " * 10 + "|\n") * 5, end="")
print("+" + 10 * "-" + "+")

# str(number) converts int/float to string
a=10
s=str(a)
print("Rohan"+" "+s)

##min(string) finds char with lowest ascii value and max highest

print("aAbByYzZaA".index("b"))#print first occurrence of b

# Demonstrating the list() function
print(list("abcabc"))# converts string into list

# Demonstrating the count() method
print("abcabc".count("b"))
print('abcabc'.count("d"))

# Demonstrating the capitalize() method
#converts only first char to uppercase
print('aBcD'.capitalize())

## Demonstrating the endswith() method
if "epsilon".endswith("on"):
    print("yes")
else:
    print("no")
    
# Demonstrating the startswith() method
print("omega".startswith("meg"))
print("omega".startswith("om"))
    
# Demonstrating the find() method
print("Eta".find("ta"))
print("Eta".find("mma"))
# start search from index of 2
print('kappa'.find('a', 2))

# Demonstrating the isalnum() method
print('lambda30'.isalnum())

# Example 1: Demonstrating the isapha() method
print("Moooo".isalpha())
print('Mu40'.isalpha())

# Example 2: Demonstrating the isdigit() method
print('2018'.isdigit())
print("Year2019".isdigit())

# Example 1: Demonstrating the islower() method
print("Moooo".islower())
print('moooo'.islower())

# Example 2: Demonstrating the isspace() method
print(' \n '.isspace())
print(" ".isspace())
print("mooo mooo mooo".isspace())

# Example 3: Demonstrating the isupper() method
print("Moooo".isupper())
print('moooo'.isupper())
print('MOOOO'.isupper())

# Demonstrating the join() method
#converts a list of strings into a string sep by comma
print(",".join(["omicron", "pi", "rho"]))


# Demonstrating the lower() method
print("SiGmA=60".lower())

## Demonstrating the lstrip() method, rstrip to remove space at end
# strip removes space at both ends
# removes leading whitespace/characters
print("[" + " tau ".lstrip() + "]")
print("www.cisco.com".lstrip("w."))
print("pythoninstitute.org".lstrip(".org"))

# Demonstrating the replace() method
# replace all instance or we can specify how many times(last 2 ex)
print("www.netacad.com".replace("netacad.com", "pythoninstitute.org"))
print("This is it!".replace("is", "are"))
print("Apple juice".replace("juice", ""))
print("This is it!".replace("is", "are", 1))
print("This is it!".replace("is", "are", 2))

# Demonstrating the rfind() method begin search from last index
print("tau tau tau".rfind("ta"))
print("tau tau tau".rfind("ta", 9))
print("tau tau tau".rfind("ta", 3, 9))

# Demonstrating the split() method
print("phi       chi\npsi".split())

# Demonstrating the swapcase() method
print("I know that I know nothing.".swapcase())
# swaps each letters case
print()

# Demonstrating the title() method
# each words first letter only is in capital
print("I know that I know nothing. Part 1.".title())

print()

# Demonstrating the upper() method
print("I know that I know nothing. Part 2.".upper())

# Demonstrating the sorted() function
firstGreek = ['omega', 'alpha', 'pi', 'gamma']
firstGreek2 = sorted(firstGreek)

print(firstGreek)
print(firstGreek2)

print()

# Demonstrating the sort() method
secondGreek = ['omega', 'alpha', 'pi', 'gamma']
print(secondGreek)

secondGreek.sort()
print(secondGreek)