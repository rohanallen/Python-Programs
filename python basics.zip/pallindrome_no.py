def rev(x):
    a=x
    if a==x[::-1]:
        print(a,"is a Pallindrome Number")
    else:
        print(a,"is a not Pallindrome Number")
s=input("Enter Number: ")
rev(s)