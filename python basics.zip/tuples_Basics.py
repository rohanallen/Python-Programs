# tuples are exactly same as lists except they are immutable
# empty tuple declaration
emptyTuple = ()
# comma at end req to diff frm variable
oneElementTuple1 = (1, )
# see output same as list
# once created a tuple cant be modified, no append del etc
myTuple = (1, 10, 100, 1000)

print(myTuple[0])
print(myTuple[-1])
print(myTuple[1:])
print(myTuple[:-2])

for elem in myTuple:
    print(elem)
    
myTuple1 = (1, 10, 100)
# when modifing result is stored in new tubl
t1 = myTuple1 + (1000, 10000)
t2 = myTuple1 * 3

print(len(t2))
print(t1)
print(t2)
print(10 in myTuple1)
print(-10 not in myTuple1)

#dictionary

dictionary = {"cat" : "chat", "dog" : "chien", "horse" : "cheval"}
phone_numbers = {'boss' : 5551234567, 'Suzy' : 22657854310}
empty_dictionary = {}

print(dictionary)
print(phone_numbers)
print(empty_dictionary)

#to get value by using key
print(dictionary['cat'])
print(phone_numbers['Suzy'])

#to browse dictionary
dictionary = {"cat" : "chat", "dog" : "chien", "horse" : "cheval"}
#modify value
dictionary['cat'] = 'minou'
# add new key->value pair 2 ways
dictionary['swan'] = 'cygne'
dictionary.update({"duck" : "canard"})
# remove key
del dictionary['dog']
#To remove the last item in a dictionary, you can use the popitem() method:
dictionary.popitem()
for key in dictionary.keys():
    print(key, "->", dictionary[key])


    