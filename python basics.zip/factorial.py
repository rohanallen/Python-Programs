class Factorial:
    fac=1# class variable
    def fact(self,x):
        for i in range(1,x+1):
            Factorial.fac=Factorial.fac*i
        return Factorial.fac
a=int(input("Enter Number: "))
obj=Factorial()
print(obj.fact(a))
            