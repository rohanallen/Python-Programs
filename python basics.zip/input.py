print("Tell me anything...")
anything = input()
print("Hmm...", anything, "... Really?")

#or
anything = input("Tell me anything...\n")
print("Hmm...", anything, "...Really?")
#We've said it already, but it must be unambiguously stated once again: the result of the input() function is a string.
# we do int(string) or float(string) to convert the string input into int or float so that mathematical opearations can be performe

anything = float(input("Enter a number: "))
something = anything ** 2.0
print(anything, "to the power of 2 is", something)