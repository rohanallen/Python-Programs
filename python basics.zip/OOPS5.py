class Classy:
    def visible(self):
        print("visible")
    
    def __hidden(self):
        print("hidden")

obj = Classy()
obj.visible()

try:
    obj.__hidden()
except:
    print("failed")

obj._Classy__hidden()

print(obj.__dict__)# content of object
print(Classy.__dict__)# content of class
print(Classy.__name__) # name of class
print(type(obj).__name__)# name of class which object instantiates
#t stores the name of the module which contains the definition of the class.
print(Classy.__module__)

print(obj.__module__)