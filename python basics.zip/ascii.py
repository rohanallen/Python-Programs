###To get ascii value
a=input("Enter any Character: ")
print(ord(a))
print()
## to get char frm ascii value

for i in range(256):
    print(chr(i),":",i)