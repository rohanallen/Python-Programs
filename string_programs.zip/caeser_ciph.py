def caesar(s,key):
    a=0
    ch=""
    for i in s:
        if i.isalpha():
            a=ord(i)+key
            if (i.isupper() and a>90 or i.islower() and a>122):
                a=a-26
        ch=ch+chr(a)
    return ch
text=input("Enter Text: ")
key=int(input("Enter Encryption key: "))
print("Encrypted Key is: ")
print(caesar(text,key))
            
        
