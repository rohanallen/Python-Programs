#Write a Python program to count the number of characters (character frequency) in a string.
def freq(s):
    s=s.lower()# to convert to lowercase
    dict={}# empty dictionary
    for i in s:# traverse thru string
        key=dict.keys()# stores all keys in dict
        if i in key:# if char in key already
            dict[i]+=1# increment value(freq) by 1
        else:
            dict[i]=1# intialize value(freq) to 1
    return dict
a=input("Enter any String: ")
print(freq(a))