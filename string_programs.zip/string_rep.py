#Write a Python program to get a string from a given string where all occurrences of its first char have been changed to '$', except the first char itself.
#Sample String : 'restart'
#Expected Result : 'resta$t'
def rep(s):
    str=""# empty syting
    s=s.lower()
    l=list(s)# covert to list to manipulate as strings are immutable
    for i in range(1,len(l)):# skip first index
        if(l[i]==l[0]):# if char== first char
            l[i]="$"
        else:
            continue
    return str.join(l)# to convert list to string and stotre in new string variable str
a=input("Enter String: ")
print(rep(a))